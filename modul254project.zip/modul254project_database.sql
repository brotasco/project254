-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema modul254project
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema modul254project
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `modul254project` DEFAULT CHARACTER SET utf8 ;
USE `modul254project` ;

-- -----------------------------------------------------
-- Table `modul254project`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modul254project`.`user` (
  `userid` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `firstname` VARCHAR(45) NOT NULL,
  `lastname` VARCHAR(45) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password` VARCHAR(1000) NOT NULL,
  `profilePic` VARCHAR(1000) NULL DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 41
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `modul254project`.`address`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modul254project`.`address` (
  `addressid` INT(11) NOT NULL AUTO_INCREMENT,
  `street` VARCHAR(45) NOT NULL,
  `number` VARCHAR(45) NOT NULL,
  `postcode` VARCHAR(45) NOT NULL,
  `city` VARCHAR(45) NOT NULL,
  `country` VARCHAR(45) NOT NULL,
  `userid` INT(11) NOT NULL,
  PRIMARY KEY (`addressid`),
  INDEX `fk_address_user_idx` (`userid` ASC),
  CONSTRAINT `fk_address_user`
    FOREIGN KEY (`userid`)
    REFERENCES `modul254project`.`user` (`userid`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
