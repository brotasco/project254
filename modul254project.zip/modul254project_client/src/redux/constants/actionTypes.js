const USER_LOGIN = 'USER_LOGIN';
const USER_LOGOUT = 'USER_LOGOUT';

export{
    USER_LOGIN,
    USER_LOGOUT
}